package com.example.testing1;

public class ReadWriteUserDetails {
    public String fullName,doB,gender,mobile;
    public ReadWriteUserDetails(String texFullname,String textDoB, String textGender, String textMobile){
        this.fullName = texFullname;
        this.doB = textDoB;
        this.gender = textGender;
        this.mobile = textMobile;

    }
}
